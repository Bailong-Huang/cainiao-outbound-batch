# 菜鸟批量出库助手 | Cainiao Batch Outbound Assistant

**Version / 版本：1.0.5**

1.0.5 labels persisted prefill failures as historical after a directory scan, so old diagnostics are not mistaken for a new failure. 1.0.4 recognizes Polish Paczkomat parcel-locker addresses. / 1.0.5 将目录扫描前已保存的预填失败标记为历史记录，避免误认为本次运行失败；1.0.4 增加波兰 Paczkomat 快递柜地址识别。

[简体中文](#简体中文) | [English](#english)

## 简体中文

### 应用场景

面向使用 AliExpress 跨境卖家中心（CSP）和菜鸟海外仓的卖家。插件帮助把待发货订单与本地 PDF 面单对应起来，读取订单资料，并将收件人、SKU 和物流信息预填到菜鸟出库委托单，减少重复复制和手工录入。

本插件是浏览器中的操作助手，不是 AliExpress 或菜鸟官方产品，也不提供订单管理或物流服务。

### 主要功能

- 选择本机面单目录，按 PDF 修改日期分组，并逐单或按日期选择订单；PDF 文件名（不含扩展名）作为订单号。
- 在已登录的 CSP 发货页面按订单号查找订单，读取商品编码和数量、买家信息、首公里服务商及运单号。
- 将收集到的订单资料保存在扩展专用 IndexedDB 中；关闭侧栏后可恢复。
- 解析常见欧洲收件地址，并在地址存在歧义时提示人工核对。
- 在菜鸟新建出库委托单页面，辅助选择波兰仓、填写订单号、匹配仓库 SKU、选择 DPD/Inpost 服务并上传对应 PDF 面单。
- 提供本机脱敏地址结构统计，帮助检查解析器对现有地址格式的覆盖情况。

### 使用流程

1. 使用 Chrome 登录 CSP，并打开“物流 → 我要发货 → 运输中 → 待揽收”页面。
2. 打开菜鸟“新建出库委托单”页面。
3. 打开扩展侧栏，选择包含订单 PDF 面单的本机目录，并授予目录读取权限。
4. 选择要处理的订单，点击“批量读取订单和地址”。检查每单的 SKU、数量、物流资料和地址解析结果。
5. 点击预填，将资料写入菜鸟表单。检查仓库、订单号、收件人、SKU 数量、物流服务、运单号和 PDF 面单。
6. 确认无误后，由用户在菜鸟页面手动创建出库单，再回到侧栏确认并继续下一单。

### 安装

1. 下载本仓库，解压到本机目录。
2. 在 Chrome 地址栏打开 `chrome://extensions`，开启“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择包含 `manifest.json` 的 `cainiao-outbound-batch` 目录。
4. 打开扩展侧栏并选择本机面单目录。仅授予插件处理工作所需的页面与目录权限。

Chrome 商店发布和自动更新尚未配置；通过“加载已解压的扩展程序”安装时，更新需要重新下载并在扩展管理页点击“重新加载”。

### 隐私与安全

- 订单资料（可能包含姓名、电话和收货地址）保存在当前 Chrome 用户配置文件的扩展 IndexedDB 中，不会发送到本项目的服务器；本项目不包含后端服务。
- 插件仅申请 CSP 与菜鸟页面访问权限、侧边栏/标签页脚本能力、本机存储和读取剪贴板权限。用户通过目录选择器明确选择面单文件夹。
- 地址统计报告只显示结构和计数，不包含订单号、姓名、电话、邮编或原始地址。
- 插件不会自动点击菜鸟“创建/提交”。用户必须核对页面并手动提交。
- 订单数据只存于对应 Chrome 配置文件。清除扩展数据、移除扩展或更换浏览器配置文件可能导致本地记录丢失。

### 兼容性说明

插件依赖 CSP 和菜鸟网页的界面结构。平台更新可能导致读取或预填步骤需要调整。请始终检查页面实际值；若某一步报告失败，不要提交该订单。地址识别属于启发式解析，无法确认的格式会要求人工核对。

## English

### Use case

This extension assists sellers who use the AliExpress Cross-border Seller Center (CSP) and Cainiao overseas warehouses. It matches pending orders with local PDF shipping labels, reads order details, and prefills recipient, SKU, and shipping data into Cainiao outbound forms to reduce repetitive copying and typing.

This is an independent browser assistant. It is not an official AliExpress or Cainiao product and does not provide order management or shipping services.

### Features

- Select a local folder of PDF labels, group files by modification date, and select orders individually or by day. The PDF filename (without its extension) is treated as the order number.
- Find selected orders in the signed-in CSP shipping page and read SKU codes and quantities, buyer details, first-mile carrier, and tracking number.
- Save collected order details in the extension's IndexedDB so they can be restored after the side panel is closed.
- Parse common European address formats and request manual review when the field order is ambiguous.
- Assist with prefilling Cainiao outbound forms: Poland warehouse, order IDs, warehouse SKU matching, DPD/InPost service selection, tracking number, and the corresponding PDF label.
- Generate a privacy-safe, local-only summary of address structures to help assess parser coverage.

### Workflow

1. Sign in to CSP in Chrome and open **Logistics → Ship Orders → In Transit → To Be Collected**.
2. Open the Cainiao **Create Outbound Order** page.
3. Open the extension side panel, select the local folder containing PDF labels, and grant read access to that folder.
4. Select orders and choose **Batch read orders and addresses**. Review the SKU, quantity, shipping details, and parsed address for each order.
5. Choose the prefilling action. Verify the warehouse, order IDs, recipient, SKU quantities, shipping service, tracking number, and attached PDF label in Cainiao.
6. After verification, manually submit the outbound order in Cainiao. Confirm completion in the side panel to continue to the next order.

### Installation

1. Download and extract this repository.
2. Open `chrome://extensions` in Chrome and enable **Developer mode**.
3. Select **Load unpacked** and choose the `cainiao-outbound-batch` folder containing `manifest.json`.
4. Open the extension side panel and select the local label folder. Grant only the page and folder access needed for the workflow.

Chrome Web Store distribution and automatic updates are not configured. For an unpacked installation, download updates and click **Reload** on the extension management page.

### Privacy and safety

- Order records may contain buyer names, phone numbers, and addresses. They are stored in the extension's IndexedDB in the current Chrome profile and are not sent to a project server. This project has no backend service.
- The extension requests access to the CSP and Cainiao pages, side panel/tab scripting, local storage, and clipboard reading. The user explicitly chooses the local label folder.
- The address report contains structural counts only; it excludes order IDs, names, phone numbers, postal codes, and raw addresses.
- The extension does not automatically click Cainiao's **Create/Submit** button. The user reviews and submits each order manually.
- Local records belong to the current Chrome profile. Clearing extension data, removing the extension, or changing profiles may delete or hide them.

### Compatibility

The extension relies on the current CSP and Cainiao page structures. Platform changes may require updates to extraction or prefilling. Always verify the actual form values and do not submit an order after a reported failure. Address parsing is heuristic; ambiguous formats require manual review.
